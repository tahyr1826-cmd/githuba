// ─── STATE ────────────────────────────────────────────────────────────────────
let currentTopic = "Les xarxes socials fan més mal que bé a la societat";
let history = [];          // { role: "user"|"assistant", content: string }[]
let userMsgCount = 0;
let isLoading = false;

// ─── DOM ──────────────────────────────────────────────────────────────────────
const screenHome   = document.getElementById("screen-home");
const screenChat   = document.getElementById("screen-chat");
const topicCards   = document.querySelectorAll(".topic-card");
const customInput  = document.getElementById("custom-topic");
const startBtn     = document.getElementById("start-btn");
const backBtn      = document.getElementById("back-btn");
const resetBtn     = document.getElementById("reset-btn");
const headerTopic  = document.getElementById("header-topic");
const chatMessages = document.getElementById("chat-messages");
const userInput    = document.getElementById("user-input");
const sendBtn      = document.getElementById("send-btn");
const scoreBar     = document.getElementById("score-bar");

// ─── TOPIC SELECTION ──────────────────────────────────────────────────────────
topicCards.forEach(card => {
  card.addEventListener("click", () => {
    topicCards.forEach(c => c.classList.remove("active"));
    card.classList.add("active");
    currentTopic = card.dataset.topic;
    customInput.value = "";
  });
});

customInput.addEventListener("input", () => {
  if (customInput.value.trim()) {
    topicCards.forEach(c => c.classList.remove("active"));
  }
});

// ─── START / BACK ─────────────────────────────────────────────────────────────
startBtn.addEventListener("click", () => {
  const custom = customInput.value.trim();
  if (custom) currentTopic = custom;

  if (!currentTopic) {
    customInput.focus();
    customInput.style.borderColor = "var(--blue)";
    return;
  }

  goToChat();
});

backBtn.addEventListener("click", goToHome);
resetBtn.addEventListener("click", resetChat);

function goToChat() {
  resetChat(false);
  screenHome.classList.remove("active");
  screenChat.classList.add("active");
  headerTopic.textContent = currentTopic;
  renderWelcome();
  userInput.focus();
}

function goToHome() {
  screenChat.classList.remove("active");
  screenHome.classList.add("active");
}

function resetChat(renderWelcomeMsg = true) {
  history = [];
  userMsgCount = 0;
  isLoading = false;
  sendBtn.disabled = false;
  chatMessages.innerHTML = "";
  scoreBar.classList.remove("visible");
  if (renderWelcomeMsg) renderWelcome();
}

function renderWelcome() {
  chatMessages.innerHTML = `
    <div class="msg-welcome">
      <div class="msg-welcome-icon">⚖️</div>
      <p>
        <strong>Tema:</strong> ${escapeHtml(currentTopic)}<br><br>
        Exposa el teu primer argument. La IA defensarà sempre la postura contrària per entrenar el teu pensament crític.
      </p>
    </div>`;
}

// ─── SEND MESSAGE ─────────────────────────────────────────────────────────────
sendBtn.addEventListener("click", handleSend);

userInput.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    handleSend();
  }
});

// auto-resize textarea
userInput.addEventListener("input", () => {
  userInput.style.height = "auto";
  userInput.style.height = Math.min(userInput.scrollHeight, 120) + "px";
});

async function handleSend() {
  const text = userInput.value.trim();
  if (!text || isLoading) return;

  isLoading = true;
  sendBtn.disabled = true;
  userInput.value = "";
  userInput.style.height = "auto";

  // Remove welcome if still visible
  const welcome = chatMessages.querySelector(".msg-welcome");
  if (welcome) welcome.remove();

  // Show user bubble
  appendBubble("user", text);
  history.push({ role: "user", content: text });
  userMsgCount++;

  // Show typing indicator
  const typingEl = appendTyping();

  try {
    const reply = await fetchGemini(text);
    typingEl.remove();
    appendBubble("ai", reply);
    history.push({ role: "assistant", content: reply });

    // Request evaluation every 3 user messages
    if (userMsgCount > 0 && userMsgCount % 3 === 0) {
      requestEvaluation();
    }
  } catch (err) {
    typingEl.remove();
    appendBubble("ai", `**Error de connexió.** No s'ha pogut contactar amb el servidor. Comprova la teva connexió i torna-ho a intentar.\n\n_Detall: ${err.message}_`);
    console.error("Gemini fetch error:", err);
  }

  isLoading = false;
  sendBtn.disabled = false;
  userInput.focus();
}

// ─── API CALL (through Netlify function) ─────────────────────────────────────
async function fetchGemini(message) {
  // Send only the last 10 messages to keep context manageable
  const recentHistory = history.slice(-10);

  const response = await fetch("/api/gemini", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message,
      topic: currentTopic,
      history: recentHistory
    })
  });

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error || `HTTP ${response.status}`);
  }

  const data = await response.json();
  if (!data.reply) throw new Error("Resposta buida del servidor");
  return data.reply;
}

// ─── EVALUATION ──────────────────────────────────────────────────────────────
async function requestEvaluation() {
  const userMessages = history
    .filter(m => m.role === "user")
    .map((m, i) => `Argument ${i + 1}: ${m.content}`)
    .join("\n");

  const evalPrompt = `Avalua els arguments d'aquest estudiant en el debat sobre: "${currentTopic}".

Arguments:
${userMessages}

Respon ÚNICAMENT amb JSON vàlid, sense text addicional ni cometes de codi:
{"arguments": <0-100>, "logica": <0-100>, "evidencies": <0-100>, "feedback": "<frase constructiva en català>"}`;

  try {
    const response = await fetch("/api/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: evalPrompt,
        topic: "avaluació",
        history: []
      })
    });

    if (!response.ok) return;
    const data = await response.json();
    let raw = (data.reply || "").replace(/```json|```/g, "").trim();
    const scores = JSON.parse(raw);
    showScores(scores);
  } catch (e) {
    console.warn("Avaluació no disponible:", e);
  }
}

function showScores(s) {
  document.getElementById("fill-arg").style.width = (s.arguments || 0) + "%";
  document.getElementById("fill-log").style.width = (s.logica || 0) + "%";
  document.getElementById("fill-evi").style.width = (s.evidencies || 0) + "%";
  document.getElementById("val-arg").textContent  = (s.arguments || "—");
  document.getElementById("val-log").textContent  = (s.logica || "—");
  document.getElementById("val-evi").textContent  = (s.evidencies || "—");
  document.getElementById("score-feedback").textContent = s.feedback || "";
  scoreBar.classList.add("visible");
}

// ─── UI HELPERS ──────────────────────────────────────────────────────────────
function appendBubble(role, text) {
  const wrap = document.createElement("div");
  wrap.className = `msg ${role}`;

  const av = document.createElement("div");
  av.className = "msg-av";
  av.textContent = role === "user" ? "Tu" : "IA";

  const bbl = document.createElement("div");
  bbl.className = "msg-bbl";
  bbl.innerHTML = formatMarkdown(text);

  wrap.appendChild(av);
  wrap.appendChild(bbl);
  chatMessages.appendChild(wrap);
  scrollBottom();
  return wrap;
}

function appendTyping() {
  const wrap = document.createElement("div");
  wrap.className = "typing-wrap";
  wrap.innerHTML = `
    <div class="msg-av" style="background:rgba(255,255,255,0.07);border:1px solid var(--border);color:var(--muted);width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.65rem;font-weight:700;font-family:'Sora',sans-serif;flex-shrink:0">IA</div>
    <div class="typing-bbl">
      <span class="t-dot"></span>
      <span class="t-dot"></span>
      <span class="t-dot"></span>
    </div>`;
  chatMessages.appendChild(wrap);
  scrollBottom();
  return wrap;
}

function scrollBottom() {
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function formatMarkdown(text) {
  // bold
  text = text.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
  // italic
  text = text.replace(/\*(.*?)\*/g, "<em>$1</em>");
  // paragraphs
  const paragraphs = text.split(/\n{2,}/);
  return paragraphs.map(p => `<p>${p.replace(/\n/g, "<br>")}</p>`).join("");
}

function escapeHtml(str) {
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
