exports.handler = async function (event, context) {
  // Only allow POST
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
  }

  const { message, topic, history } = body;

  if (!message || !topic) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing message or topic" }) };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: "API key not configured" }) };
  }

  const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

  const systemPrompt = `Ets un filòsof i expert en debat. El tema del debat és: "${topic}".

La teva missió és SEMPRE defensar la postura CONTRÀRIA a la que defensa l'usuari. Si l'usuari diu que quelcom és bo, tu argumentes que és dolent, i viceversa. No cedeixis mai la teva posició.

REGLES:
- Detecta fal·làcies argumentatives en els arguments de l'usuari i assenyala-les educadament.
- Usa lògica, evidències i exemples per contrargumentar.
- Sigues desafiador però sempre respectuós i acadèmic.
- Respon SEMPRE en català.
- Limita les teves respostes a un MÀXIM de 2 paràgrafs.
- Al final, fes sempre una pregunta directa per reptar l'usuari a defensar el seu punt de vista.
- No et presentis com a IA; actua com un debatedor humà expert.`;

  // Build conversation history for Gemini
  const contents = [];

  // Add previous messages if any
  if (history && Array.isArray(history)) {
    for (const msg of history) {
      contents.push({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }]
      });
    }
  }

  // Add current user message
  contents.push({
    role: "user",
    parts: [{ text: message }]
  });

  try {
    const response = await fetch(GEMINI_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: systemPrompt }] },
        contents: contents,
        generationConfig: {
          temperature: 0.85,
          maxOutputTokens: 500
        }
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      return { statusCode: response.status, body: JSON.stringify({ error: errText }) };
    }

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!text) {
      return { statusCode: 500, body: JSON.stringify({ error: "Empty response from Gemini" }) };
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reply: text })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || "Internal server error" })
    };
  }
};
